// Practical 2 - Parking lot hashing with linear probing
// MITAOE Data Structures and Algorithm Lab - Assignment_02_Hashing

#include <iostream>
using namespace std;
const int SIZE=10;
int table[SIZE];
int hashFunction(int reg){return reg%SIZE;}
void insertVehicle(int reg){
 int index=hashFunction(reg),start=index;
 while(table[index]!=-1){if(table[index]==reg){cout<<"Vehicle already parked at slot "<<index<<"\\n";return;}index=(index+1)%SIZE;if(index==start){cout<<"Parking full\\n";return;}}
 table[index]=reg;cout<<"Vehicle parked at slot "<<index<<"\\n";
}
int searchVehicle(int reg){int index=hashFunction(reg),start=index;while(table[index]!=-1){if(table[index]==reg)return index;index=(index+1)%SIZE;if(index==start)break;}return -1;}
int main(){for(int &x:table)x=-1;int ch,reg;
 do{cout<<"\\n1.Park vehicle 2.Search vehicle 3.Display slots 4.Exit\\n";cin>>ch;
 if(ch==1){cout<<"Registration number (integer): ";cin>>reg;insertVehicle(reg);}
 else if(ch==2){cout<<"Registration number: ";cin>>reg;int p=searchVehicle(reg);if(p==-1)cout<<"Vehicle not found\\n";else cout<<"Vehicle found at slot "<<p<<"\\n";}
 else if(ch==3){for(int i=0;i<SIZE;i++)cout<<i<<": "<<(table[i]==-1? -1:table[i])<<"\\n";}
 }while(ch!=4);
}
