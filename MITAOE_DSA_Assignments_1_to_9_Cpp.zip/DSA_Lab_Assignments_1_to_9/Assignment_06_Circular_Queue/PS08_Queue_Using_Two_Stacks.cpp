// Practice Problem 8 - Queue using two stacks
// MITAOE Data Structures and Algorithm Lab - Assignment_06_Circular_Queue

#include <iostream>
#include <stack>
using namespace std;
stack<int>s1,s2;
void enqueue(int x){s1.push(x);}
void transfer(){if(s2.empty())while(!s1.empty()){s2.push(s1.top());s1.pop();}}
void dequeue(){transfer();if(s2.empty()){cout<<"Queue empty\\n";return;}cout<<"Removed: "<<s2.top()<<"\\n";s2.pop();}
void display(){stack<int>a=s2,b=s1;while(!a.empty()){cout<<a.top()<<" ";a.pop();}while(!b.empty())b.pop(); // make a copy of s1 in insertion order
 stack<int> temp=s1,rev;while(!temp.empty()){rev.push(temp.top());temp.pop();}while(!rev.empty()){cout<<rev.top()<<" ";rev.pop();}cout<<"\\n";}
int main(){int c,x;do{cout<<"\\n1.Enqueue 2.Dequeue 3.Display 4.Exit\\n";cin>>c;switch(c){case 1:cin>>x;enqueue(x);break;case 2:dequeue();break;case 3:display();break;}}while(c!=4);}
