// Practice Problem 7 - Queue using linked list
// MITAOE Data Structures and Algorithm Lab - Assignment_06_Circular_Queue

#include <iostream>
using namespace std;
struct Node{int data;Node*next;Node(int x):data(x),next(NULL){}};Node*frontNode=NULL,*rearNode=NULL;
void enqueue(int x){Node*n=new Node(x);if(!rearNode)frontNode=rearNode=n;else{rearNode->next=n;rearNode=n;}}
void dequeue(){if(!frontNode){cout<<"Queue underflow\\n";return;}Node*t=frontNode;cout<<"Deleted: "<<t->data<<"\\n";frontNode=frontNode->next;if(!frontNode)rearNode=NULL;delete t;}
void display(){for(Node*t=frontNode;t;t=t->next)cout<<t->data<<" ";cout<<"\\n";}
int main(){int c,x;do{cout<<"\\n1.Enqueue 2.Dequeue 3.Display 4.Exit\\n";cin>>c;switch(c){case 1:cin>>x;enqueue(x);break;case 2:dequeue();break;case 3:display();break;}}while(c!=4);}
