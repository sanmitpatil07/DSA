// Practical 6 - Circular queue service request system
// MITAOE Data Structures and Algorithm Lab - Assignment_06_Circular_Queue

#include <iostream>
using namespace std;
const int SIZE=5;int q[SIZE],front=-1,rear=-1;
bool empty(){return front==-1;}bool full(){return (rear+1)%SIZE==front;}
void enqueue(int x){if(full()){cout<<"Queue full\\n";return;}if(empty())front=0;rear=(rear+1)%SIZE;q[rear]=x;cout<<"Request added\\n";}
void dequeue(){if(empty()){cout<<"No pending requests\\n";return;}cout<<"Resolved request: "<<q[front]<<"\\n";if(front==rear)front=rear=-1;else front=(front+1)%SIZE;}
void display(){if(empty()){cout<<"Queue empty\\n";return;}int i=front;while(true){cout<<q[i]<<" ";if(i==rear)break;i=(i+1)%SIZE;}cout<<"\\n";}
int main(){int c,x;do{cout<<"\\n1.Add request 2.Resolve request 3.Display 4.Exit\\n";cin>>c;switch(c){case 1:cin>>x;enqueue(x);break;case 2:dequeue();break;case 3:display();break;}}while(c!=4);}
