// Practical 8 - Student record management using binary search tree
// MITAOE Data Structures and Algorithm Lab - Assignment_08_BST

#include <iostream>
using namespace std;
struct Node{int roll;Node*l,*r;Node(int x):roll(x),l(NULL),r(NULL){}};
Node*insert(Node*t,int x){if(!t)return new Node(x);if(x<t->roll)t->l=insert(t->l,x);else if(x>t->roll)t->r=insert(t->r,x);else cout<<"Duplicate roll number\\n";return t;}
Node*search(Node*t,int x){if(!t||t->roll==x)return t;return x<t->roll?search(t->l,x):search(t->r,x);}
Node*minimum(Node*t){if(!t)return NULL;while(t->l)t=t->l;return t;}Node*maximum(Node*t){if(!t)return NULL;while(t->r)t=t->r;return t;}
Node*predecessor(Node*root,int x){Node*t=search(root,x);if(!t)return NULL;if(t->l)return maximum(t->l);Node*p=NULL;while(root){if(x>root->roll){p=root;root=root->r;}else if(x<root->roll)root=root->l;else break;}return p;}
Node*successor(Node*root,int x){Node*t=search(root,x);if(!t)return NULL;if(t->r)return minimum(t->r);Node*p=NULL;while(root){if(x<root->roll){p=root;root=root->l;}else if(x>root->roll)root=root->r;else break;}return p;}
Node*erase(Node*t,int x){if(!t)return NULL;if(x<t->roll)t->l=erase(t->l,x);else if(x>t->roll)t->r=erase(t->r,x);else{if(!t->l){Node*q=t->r;delete t;return q;}if(!t->r){Node*q=t->l;delete t;return q;}Node*q=minimum(t->r);t->roll=q->roll;t->r=erase(t->r,q->roll);}return t;}
void inorder(Node*t){if(t){inorder(t->l);cout<<t->roll<<" ";inorder(t->r);}}void preorder(Node*t){if(t){cout<<t->roll<<" ";preorder(t->l);preorder(t->r);}}void postorder(Node*t){if(t){postorder(t->l);postorder(t->r);cout<<t->roll<<" ";}}
int main(){Node*root=NULL;int c,x;do{cout<<"\\n1.Insert 2.Search 3.Minimum 4.Maximum 5.Predecessor 6.Successor 7.Delete 8.Inorder 9.Preorder 10.Postorder 11.Exit\\n";cin>>c;Node*t=NULL;switch(c){case 1:cin>>x;root=insert(root,x);break;case 2:cin>>x;cout<<(search(root,x)?"Found":"Not found")<<"\\n";break;case 3:t=minimum(root);if(t)cout<<t->roll<<"\\n";else cout<<"Tree empty\\n";break;case 4:t=maximum(root);if(t)cout<<t->roll<<"\\n";else cout<<"Tree empty\\n";break;case 5:cin>>x;t=predecessor(root,x);if(t)cout<<t->roll<<"\\n";else cout<<"No predecessor or key missing\\n";break;case 6:cin>>x;t=successor(root,x);if(t)cout<<t->roll<<"\\n";else cout<<"No successor or key missing\\n";break;case 7:cin>>x;root=erase(root,x);break;case 8:inorder(root);cout<<"\\n";break;case 9:preorder(root);cout<<"\\n";break;case 10:postorder(root);cout<<"\\n";break;}}while(c!=11);}
