// Practical 3.1 - Selection sort student marks ascending
// MITAOE Data Structures and Algorithm Lab - Assignment_03_Searching_Sorting

#include <iostream>
using namespace std;
int main(){int n,a[100];cout<<"Number of students: ";cin>>n;if(n<1||n>100)return 0;for(int i=0;i<n;i++)cin>>a[i];
 for(int i=0;i<n-1;i++){int m=i;for(int j=i+1;j<n;j++)if(a[j]<a[m])m=j;swap(a[i],a[m]);}
 cout<<"Ascending marks: ";for(int i=0;i<n;i++)cout<<a[i]<<" ";}
