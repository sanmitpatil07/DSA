// Practical 3.5 - Sentinel search product ID
// MITAOE Data Structures and Algorithm Lab - Assignment_03_Searching_Sorting

#include <iostream>
using namespace std;
int main(){int n,a[101],key;cout<<"Number of products: ";cin>>n;if(n<0||n>100)return 0;cout<<"Enter product IDs: ";for(int i=0;i<n;i++)cin>>a[i];cout<<"Search product ID: ";cin>>key;a[n]=key;int i=0;while(a[i]!=key)i++;if(i==n)cout<<"Product Not Available\\n";else cout<<"Product found at position "<<i+1<<"\\n";}
