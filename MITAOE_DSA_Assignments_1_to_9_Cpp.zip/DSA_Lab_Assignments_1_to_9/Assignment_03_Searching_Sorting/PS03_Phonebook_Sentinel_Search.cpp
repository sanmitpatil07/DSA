// Practice Problem 3 - Sorted phonebook and sentinel search
// MITAOE Data Structures and Algorithm Lab - Assignment_03_Searching_Sorting

#include <iostream>
#include <string>
using namespace std;
struct Friend{string name,mobile;};
int main(){Friend f[101],key;int n;cout<<"Number of friends: ";cin>>n;if(n<0||n>100)return 0;for(int i=0;i<n;i++){cout<<"Name and mobile: ";cin>>f[i].name>>f[i].mobile;}
 for(int i=0;i<n-1;i++)for(int j=0;j<n-i-1;j++)if(f[j].name>f[j+1].name)swap(f[j],f[j+1]);
 cout<<"Friend name to search: ";cin>>key.name;f[n].name=key.name;int i=0;while(f[i].name!=key.name)i++;
 if(i<n)cout<<"Found: "<<f[i].name<<" - "<<f[i].mobile<<"\\n";
 else{cout<<"Not found. Enter mobile: ";cin>>key.mobile;i=n-1;while(i>=0&&f[i].name>key.name){f[i+1]=f[i];i--;}f[i+1]=key;n++;cout<<"Friend inserted.\\n";}
 for(int j=0;j<n;j++)cout<<f[j].name<<" - "<<f[j].mobile<<"\\n";
}
