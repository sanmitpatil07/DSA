// Practice Problem 4 - Merge sort floating-point percentages
// MITAOE Data Structures and Algorithm Lab - Assignment_03_Searching_Sorting

#include <iostream>
using namespace std;
void merge(float a[],int l,int m,int r){float t[100];int i=l,j=m+1,k=0;while(i<=m&&j<=r)t[k++]=(a[i]<=a[j])?a[i++]:a[j++];while(i<=m)t[k++]=a[i++];while(j<=r)t[k++]=a[j++];for(i=0;i<k;i++)a[l+i]=t[i];}
void mergeSort(float a[],int l,int r){if(l<r){int m=(l+r)/2;mergeSort(a,l,m);mergeSort(a,m+1,r);merge(a,l,m,r);}}
int main(){int n;float p[100];cout<<"Number of students: ";cin>>n;if(n<1||n>100)return 0;cout<<"Enter percentages: ";for(int i=0;i<n;i++)cin>>p[i];mergeSort(p,0,n-1);cout<<"Ascending percentages: ";for(int i=0;i<n;i++)cout<<p[i]<<" ";}
