// Practical 3.3 - Quick sort product ratings descending
// MITAOE Data Structures and Algorithm Lab - Assignment_03_Searching_Sorting

#include <iostream>
using namespace std;
int partition(float a[],int low,int high){float pivot=a[high];int i=low-1;for(int j=low;j<high;j++)if(a[j]>pivot)swap(a[++i],a[j]);swap(a[i+1],a[high]);return i+1;}
void quickSort(float a[],int low,int high){if(low<high){int p=partition(a,low,high);quickSort(a,low,p-1);quickSort(a,p+1,high);}}
int main(){int n;float a[100];cout<<"Number of products: ";cin>>n;if(n<1||n>100)return 0;cout<<"Enter ratings: ";for(int i=0;i<n;i++)cin>>a[i];quickSort(a,0,n-1);cout<<"Ratings high to low: ";for(int i=0;i<n;i++)cout<<a[i]<<" ";}
