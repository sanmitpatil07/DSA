// Practice Problem 10 - Palindrome check using deque
// MITAOE Data Structures and Algorithm Lab - Assignment_07_Deque

#include <iostream>
#include <deque>
#include <string>
#include <cctype>
using namespace std;
int main(){string s;deque<char>d;cout<<"Enter string: ";getline(cin,s);for(unsigned char c:s)if(isalnum(c))d.push_back((char)tolower(c));bool ok=true;while(d.size()>1){if(d.front()!=d.back()){ok=false;break;}d.pop_front();d.pop_back();}cout<<(ok?"Palindrome":"Not a palindrome")<<"\\n";}
