// Practical 7(b) - Output restricted deque: insertion both ends, deletion front
// MITAOE Data Structures and Algorithm Lab - Assignment_07_Deque

#include <iostream>
using namespace std;const int N=5;int d[N],f=-1,r=-1;bool empty(){return f==-1;}bool full(){return (r+1)%N==f;}
void insertRear(int x){if(full()){cout<<"Full\\n";return;}if(empty())f=r=0;else r=(r+1)%N;d[r]=x;}
void insertFront(int x){if(full()){cout<<"Full\\n";return;}if(empty())f=r=0;else f=(f-1+N)%N;d[f]=x;}
void deleteFront(){if(empty()){cout<<"Empty\\n";return;}cout<<"Deleted "<<d[f]<<"\\n";if(f==r)f=r=-1;else f=(f+1)%N;}
void display(){if(empty()){cout<<"Empty\\n";return;}for(int i=f;;i=(i+1)%N){cout<<d[i]<<" ";if(i==r)break;}cout<<"\\n";}
int main(){int c,x;do{cout<<"\\n1.Insert front 2.Insert rear 3.Delete front 4.Display 5.Exit\\n";cin>>c;switch(c){case 1:cin>>x;insertFront(x);break;case 2:cin>>x;insertRear(x);break;case 3:deleteFront();break;case 4:display();break;}}while(c!=5);}
