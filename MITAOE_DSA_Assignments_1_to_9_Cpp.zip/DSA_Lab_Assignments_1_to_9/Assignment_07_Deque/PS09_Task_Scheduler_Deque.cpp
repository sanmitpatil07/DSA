// Practice Problem 9 - Task scheduler using deque
// MITAOE Data Structures and Algorithm Lab - Assignment_07_Deque

#include <iostream>
#include <deque>
using namespace std;
int main(){deque<int>tasks;int c,x;do{cout<<"\\n1.Add high priority (front) 2.Add normal (rear) 3.Process next 4.Display 5.Exit\\n";cin>>c;switch(c){case 1:cin>>x;tasks.push_front(x);break;case 2:cin>>x;tasks.push_back(x);break;case 3:if(tasks.empty())cout<<"No tasks\\n";else{cout<<"Processing task "<<tasks.front()<<"\\n";tasks.pop_front();}break;case 4:for(int t:tasks)cout<<t<<" ";cout<<"\\n";break;}}while(c!=5);}
