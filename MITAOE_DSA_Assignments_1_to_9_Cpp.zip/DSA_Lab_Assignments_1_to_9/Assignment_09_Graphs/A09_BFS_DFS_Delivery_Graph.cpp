// Practical 9 - BFS shortest route and DFS graph traversal
// MITAOE Data Structures and Algorithm Lab - Assignment_09_Graphs

#include <iostream>
#include <queue>
using namespace std;
const int V=6;int graph[V][V]={0};
void addEdge(int u,int v){graph[u][v]=graph[v][u]=1;}
void BFS(int start,int dest){bool seen[V]={false};int parent[V];for(int&i:parent)i=-1;queue<int>q;seen[start]=true;q.push(start);while(!q.empty()){int u=q.front();q.pop();if(u==dest)break;for(int v=0;v<V;v++)if(graph[u][v]&&!seen[v]){seen[v]=true;parent[v]=u;q.push(v);}}if(!seen[dest]){cout<<"No route found\\n";return;}int path[V],n=0;for(int x=dest;x!=-1;x=parent[x])path[n++]=x;cout<<"Shortest route: ";for(int i=n-1;i>=0;i--)cout<<path[i]<<" ";cout<<"\\nNumber of roads: "<<n-1<<"\\n";}
void DFS(int u,bool seen[]){seen[u]=true;cout<<u<<" ";for(int v=0;v<V;v++)if(graph[u][v]&&!seen[v])DFS(v,seen);}
int main(){addEdge(0,1);addEdge(0,2);addEdge(1,3);addEdge(2,3);addEdge(3,4);addEdge(4,5);int s,d;cout<<"Locations numbered 0 to 5.\\nStart: ";cin>>s;cout<<"Destination: ";cin>>d;if(s<0||s>=V||d<0||d>=V){cout<<"Invalid location\\n";return 0;}BFS(s,d);bool seen[V]={false};cout<<"DFS traversal from start: ";DFS(s,seen);cout<<"\\n";}
