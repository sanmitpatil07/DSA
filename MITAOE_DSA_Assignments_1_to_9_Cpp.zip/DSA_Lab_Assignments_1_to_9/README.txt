MITAOE - DATA STRUCTURES AND ALGORITHM LAB
Assignments 1 to 9 | C++ source files

FOLDER STRUCTURE
- Assignment_01_Arrays: Practical 1 + Practice Problem 1
- Assignment_02_Hashing: Practical 2 (parking lot, linear probing)
- Assignment_03_Searching_Sorting: Practical 3 (five tasks) + Practice Problems 3 and 4
- Assignment_04_Linked_Lists: Practical 4 (SLL, DLL, CLL applications)
- Assignment_05_Stack: Practical 5 (infix-to-postfix, postfix evaluation, linked-list stack) + Practice Problem 6
- Assignment_06_Circular_Queue: Practical 6 + Practice Problems 7 and 8
- Assignment_07_Deque: Practical 7 (both deque types) + Practice Problems 9 and 10
- Assignment_08_BST: Practical 8
- Assignment_09_Graphs: Practical 9 (BFS and DFS)

HOW TO COMPILE (g++):
  g++ filename.cpp -o program
  ./program                 (Linux/macOS)
  program.exe               (Windows)

Notes:
- Each .cpp file is a separate program and has its own main(). Compile one file at a time.
- Programs use standard C++ headers and are suitable for g++/Online GDB.
- Some demonstrations use fixed-size arrays or sample graph vertices, as appropriate for beginner lab practice.
- The assignment/practice-problem mapping follows the uploaded MITAOE Data Structures and Algorithm Lab PDF.
