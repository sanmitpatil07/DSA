// Practical 4 - Doubly linked list train reservation seats
// MITAOE Data Structures and Algorithm Lab - Assignment_04_Linked_Lists

#include <iostream>
using namespace std;
struct Node{int seat;Node*prev,*next;Node(int x):seat(x),prev(NULL),next(NULL){}};Node*head=NULL;
void insert(int x){Node*n=new Node(x);if(!head){head=n;return;}Node*t=head;while(t->next)t=t->next;t->next=n;n->prev=t;}
void forward(){for(Node*t=head;t;t=t->next)cout<<t->seat<<" <-> ";cout<<"NULL\\n";}
void backward(){if(!head)return;Node*t=head;while(t->next)t=t->next;for(;t;t=t->prev)cout<<t->seat<<" <-> ";cout<<"NULL\\n";}
void search(int x){for(Node*t=head;t;t=t->next)if(t->seat==x){cout<<"Seat found\\n";return;}cout<<"Seat not found\\n";}
void update(int x,int y){for(Node*t=head;t;t=t->next)if(t->seat==x){t->seat=y;return;}cout<<"Seat not found\\n";}
void erase(int x){Node*t=head;while(t&&t->seat!=x)t=t->next;if(!t){cout<<"Seat not found\\n";return;}if(t->prev)t->prev->next=t->next;else head=t->next;if(t->next)t->next->prev=t->prev;delete t;}
void sortList(){for(Node*i=head;i;i=i->next)for(Node*j=i->next;j;j=j->next)if(i->seat>j->seat)swap(i->seat,j->seat);}
int main(){int c,x,y;do{cout<<"\\n1.Insert 2.Forward 3.Backward 4.Search 5.Update 6.Delete 7.Sort 8.Exit\\n";cin>>c;switch(c){case 1:cin>>x;insert(x);break;case 2:forward();break;case 3:backward();break;case 4:cin>>x;search(x);break;case 5:cin>>x>>y;update(x,y);break;case 6:cin>>x;erase(x);break;case 7:sortList();break;}}while(c!=8);}
