// Practical 4 - Singly linked list call log
// MITAOE Data Structures and Algorithm Lab - Assignment_04_Linked_Lists

#include <iostream>
using namespace std;
struct Node{long long number;Node*next;Node(long long x):number(x),next(NULL){}};Node*head=NULL;
void insert(long long x){Node*n=new Node(x);if(!head){head=n;return;}Node*t=head;while(t->next)t=t->next;t->next=n;}
void display(){for(Node*t=head;t;t=t->next)cout<<t->number<<" -> ";cout<<"NULL\\n";}
void search(long long x){for(Node*t=head;t;t=t->next)if(t->number==x){cout<<"Call found\\n";return;}cout<<"Call not found\\n";}
void update(long long oldv,long long newv){for(Node*t=head;t;t=t->next)if(t->number==oldv){t->number=newv;cout<<"Updated\\n";return;}cout<<"Not found\\n";}
void erase(long long x){Node*t=head,*p=NULL;while(t&&t->number!=x){p=t;t=t->next;}if(!t){cout<<"Not found\\n";return;}if(p)p->next=t->next;else head=t->next;delete t;}
void sortList(){for(Node*i=head;i;i=i->next)for(Node*j=i->next;j;j=j->next)if(i->number>j->number)swap(i->number,j->number);}
int main(){int c;long long x,y;do{cout<<"\\n1.Insert 2.Display 3.Search 4.Update 5.Delete 6.Sort 7.Exit\\n";cin>>c;switch(c){case 1:cin>>x;insert(x);break;case 2:display();break;case 3:cin>>x;search(x);break;case 4:cin>>x>>y;update(x,y);break;case 5:cin>>x;erase(x);break;case 6:sortList();break;}}while(c!=7);}
