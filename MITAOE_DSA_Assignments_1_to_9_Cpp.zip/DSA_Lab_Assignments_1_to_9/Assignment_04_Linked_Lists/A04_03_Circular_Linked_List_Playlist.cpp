// Practical 4 - Circular linked list music playlist
// MITAOE Data Structures and Algorithm Lab - Assignment_04_Linked_Lists

#include <iostream>
using namespace std;
struct Node{int song;Node*next;Node(int x):song(x),next(NULL){}};Node*head=NULL;
void insert(int x){Node*n=new Node(x);if(!head){head=n;n->next=head;return;}Node*t=head;while(t->next!=head)t=t->next;t->next=n;n->next=head;}
void display(){if(!head){cout<<"Playlist empty\\n";return;}Node*t=head;do{cout<<t->song<<" -> ";t=t->next;}while(t!=head);cout<<"(head)\\n";}
void search(int x){if(!head)return;Node*t=head;do{if(t->song==x){cout<<"Song found\\n";return;}t=t->next;}while(t!=head);cout<<"Song not found\\n";}
void update(int x,int y){if(!head)return;Node*t=head;do{if(t->song==x){t->song=y;return;}t=t->next;}while(t!=head);cout<<"Song not found\\n";}
void erase(int x){if(!head){cout<<"Empty\\n";return;}Node*t=head,*p=NULL;do{if(t->song==x)break;p=t;t=t->next;}while(t!=head);if(t->song!=x){cout<<"Not found\\n";return;}if(t==head&&t->next==head)head=NULL;else if(t==head){Node*last=head;while(last->next!=head)last=last->next;head=head->next;last->next=head;}else p->next=t->next;delete t;}
void sortList(){if(!head)return;for(Node*i=head;;i=i->next){for(Node*j=i->next;j!=head;j=j->next)if(i->song>j->song)swap(i->song,j->song);if(i->next==head)break;}}
int main(){int c,x,y;do{cout<<"\\n1.Add 2.Display 3.Search 4.Update 5.Delete 6.Sort 7.Exit\\n";cin>>c;switch(c){case 1:cin>>x;insert(x);break;case 2:display();break;case 3:cin>>x;search(x);break;case 4:cin>>x>>y;update(x,y);break;case 5:cin>>x;erase(x);break;case 6:sortList();break;}}while(c!=7);}
