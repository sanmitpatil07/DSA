// Practice Problem 1 - Student mark analysis using arrays
// MITAOE Data Structures and Algorithm Lab - Assignment_01_Arrays

#include <iostream>
using namespace std;
int main(){
 int n,marks[100],sum=0;
 cout<<"Enter number of students: ";cin>>n;
 if(n<1||n>100)return 0;
 for(int i=0;i<n;i++){cout<<"Marks of student "<<i+1<<": ";cin>>marks[i];sum+=marks[i];}
 cout<<"Student marks: ";for(int i=0;i<n;i++)cout<<marks[i]<<" ";
 cout<<"\\nAverage = "<<(float)sum/n;
 int high=marks[0],low=marks[0];
 for(int i=1;i<n;i++){if(marks[i]>high)high=marks[i];if(marks[i]<low)low=marks[i];}
 cout<<"\\nHighest = "<<high<<"\\nLowest = "<<low<<"\\n";
}
