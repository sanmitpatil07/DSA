// Array insertion, updation, deletion and display
// MITAOE Data Structures and Algorithm Lab - Assignment_01_Arrays

#include <iostream>
using namespace std;
int main(){
 int a[100],n,ch,pos,val;
 cout<<"Enter number of elements: "; cin>>n;
 if(n<0||n>100) return 0;
 cout<<"Enter elements: "; for(int i=0;i<n;i++) cin>>a[i];
 do{
  cout<<"\\n1.Insert 2.Update 3.Delete 4.Display 5.Exit\\nChoice: "; cin>>ch;
  if(ch==1){
   if(n==100){cout<<"Array full\\n";continue;}
   cout<<"Enter position (1 to "<<n+1<<") and value: ";cin>>pos>>val;
   if(pos<1||pos>n+1){cout<<"Invalid position\\n";continue;}
   for(int i=n;i>=pos;i--) a[i]=a[i-1]; a[pos-1]=val; n++;
  }else if(ch==2){
   cout<<"Enter position and new value: ";cin>>pos>>val;
   if(pos<1||pos>n) cout<<"Invalid position\\n"; else a[pos-1]=val;
  }else if(ch==3){
   cout<<"Enter position to delete: ";cin>>pos;
   if(pos<1||pos>n) cout<<"Invalid position\\n";
   else{for(int i=pos-1;i<n-1;i++)a[i]=a[i+1];n--;}
  }else if(ch==4){for(int i=0;i<n;i++)cout<<a[i]<<" ";cout<<"\\n";}
 }while(ch!=5);
}
