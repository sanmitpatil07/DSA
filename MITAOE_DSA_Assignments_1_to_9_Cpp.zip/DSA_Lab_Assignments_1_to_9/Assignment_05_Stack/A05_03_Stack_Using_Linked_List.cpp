// Practical 5(c) - Stack using linked list
// MITAOE Data Structures and Algorithm Lab - Assignment_05_Stack

#include <iostream>
using namespace std;
struct Node{int data;Node*next;Node(int x,Node*n):data(x),next(n){}};Node*topNode=NULL;
void push(int x){topNode=new Node(x,topNode);}
void pop(){if(!topNode){cout<<"Stack underflow\\n";return;}Node*t=topNode;cout<<"Popped: "<<t->data<<"\\n";topNode=topNode->next;delete t;}
void peek(){if(topNode)cout<<"Top: "<<topNode->data<<"\\n";else cout<<"Stack empty\\n";}
void display(){for(Node*t=topNode;t;t=t->next)cout<<t->data<<"\\n";}
int main(){int c,x;do{cout<<"\\n1.Push 2.Pop 3.Peek 4.Display 5.Exit\\n";cin>>c;switch(c){case 1:cin>>x;push(x);break;case 2:pop();break;case 3:peek();break;case 4:display();break;}}while(c!=5);}
