// Practical 5(a) - Infix to postfix conversion
// MITAOE Data Structures and Algorithm Lab - Assignment_05_Stack

#include <iostream>
#include <stack>
#include <string>
#include <cctype>
using namespace std;
int prec(char c){if(c=='^')return 3;if(c=='*'||c=='/')return 2;if(c=='+'||c=='-')return 1;return 0;}
int main(){string s,out="";stack<char> st;cout<<"Enter infix expression (single-character operands): ";cin>>s;
 for(char c:s){if(isalnum((unsigned char)c))out+=c;else if(c=='(')st.push(c);else if(c==')'){while(!st.empty()&&st.top()!='('){out+=st.top();st.pop();}if(st.empty()){cout<<"Invalid parentheses";return 0;}st.pop();}else{while(!st.empty()&&st.top()!='('&&(prec(st.top())>prec(c)||(prec(st.top())==prec(c)&&c!='^'))){out+=st.top();st.pop();}st.push(c);}}
 while(!st.empty()){if(st.top()=='('){cout<<"Invalid parentheses";return 0;}out+=st.top();st.pop();}cout<<"Postfix: "<<out;
}
