// Practical 5(b) - Postfix evaluation for single digit operands
// MITAOE Data Structures and Algorithm Lab - Assignment_05_Stack

#include <iostream>
#include <stack>
#include <string>
#include <cctype>
using namespace std;
int main(){string s;stack<int> st;cout<<"Enter postfix expression (single-digit operands): ";cin>>s;
 for(char c:s){if(isdigit((unsigned char)c))st.push(c-'0');else{if(st.size()<2){cout<<"Invalid expression";return 0;}int b=st.top();st.pop();int a=st.top();st.pop();switch(c){case '+':st.push(a+b);break;case '-':st.push(a-b);break;case '*':st.push(a*b);break;case '/':if(b==0){cout<<"Division by zero";return 0;}st.push(a/b);break;default:cout<<"Unsupported operator";return 0;}}}
 if(st.size()==1)cout<<"Result: "<<st.top();else cout<<"Invalid expression";
}
