// Practice Problem 6 - Implement stack using two queues
// MITAOE Data Structures and Algorithm Lab - Assignment_05_Stack

#include <iostream>
#include <queue>
using namespace std;
queue<int> q1,q2;
void push(int x){q2.push(x);while(!q1.empty()){q2.push(q1.front());q1.pop();}swap(q1,q2);cout<<"Pushed\\n";}
void pop(){if(q1.empty()){cout<<"Stack underflow\\n";return;}cout<<"Popped: "<<q1.front()<<"\\n";q1.pop();}
void peek(){if(q1.empty())cout<<"Stack empty\\n";else cout<<"Top: "<<q1.front()<<"\\n";}
void display(){queue<int> t=q1;while(!t.empty()){cout<<t.front()<<" ";t.pop();}cout<<"\\n";}
int main(){int c,x;do{cout<<"\\n1.Push 2.Pop 3.Peek 4.Display 5.Exit\\n";cin>>c;switch(c){case 1:cin>>x;push(x);break;case 2:pop();break;case 3:peek();break;case 4:display();break;}}while(c!=5);}
